@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /W4 /WX /MT /O2 /Fe:"D:\a\TunnelVibeMt5-Chatgpt-max\TunnelVibeMt5-Chatgpt-max\fleet-v1-source\q1-harmless\fixture.exe" /Fo:"D:\a\TunnelVibeMt5-Chatgpt-max\TunnelVibeMt5-Chatgpt-max\fleet-v1-source\q1-harmless\fixture.obj" "D:\a\TunnelVibeMt5-Chatgpt-max\TunnelVibeMt5-Chatgpt-max\tests\proofs\tip057rq\fixture_worker.c" advapi32.lib
exit /b %errorlevel%
